import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'light' | 'dark';
}

const Logo: React.FC<LogoProps> = ({ 
  className = '', 
  size = 'md',
  variant = 'light'
}) => {
  const sizeClasses = {
    sm: 'w-10 h-10',
    md: 'w-12 h-12',
    lg: 'w-16 h-16'
  };

  const textSizeClasses = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-lg'
  };

  return (
    <div className={`flex items-center space-x-3 ${className}`}>
      <div className={`${sizeClasses[size]} relative flex items-center justify-center`}>
        <svg 
          viewBox="0 0 200 200" 
          className="w-full h-full"
          fill="none"
        >
          <defs>
            {/* Gradient for the X */}
            <linearGradient id="xGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f5f1e8" />
              <stop offset="30%" stopColor="#e8d5b7" />
              <stop offset="70%" stopColor="#d4af8c" />
              <stop offset="100%" stopColor="#f97316" />
            </linearGradient>
            
            {/* Subtle texture pattern */}
            <pattern id="texturePattern" patternUnits="userSpaceOnUse" width="4" height="4">
              <rect width="4" height="4" fill="url(#xGradient)" />
              <circle cx="2" cy="2" r="0.5" fill="rgba(255,255,255,0.1)" />
            </pattern>
          </defs>
          
          {/* Dark circular background */}
          <circle 
            cx="100" 
            cy="100" 
            r="95" 
            fill="#1f2937"
            stroke="rgba(0,0,0,0.1)"
            strokeWidth="2"
          />
          
          {/* Large X shape with gradient */}
          <g>
            {/* Left part of X */}
            <path
              d="M45 45 L85 85 L45 125 L35 115 L65 85 L35 55 Z"
              fill="url(#texturePattern)"
              className="drop-shadow-lg"
            />
            
            {/* Right part of X */}
            <path
              d="M115 45 L155 85 L115 125 L105 115 L135 85 L105 55 Z"
              fill="url(#texturePattern)"
              className="drop-shadow-lg"
            />
            
            {/* Center connecting piece */}
            <path
              d="M85 75 L115 75 L115 95 L85 95 Z"
              fill="url(#texturePattern)"
              className="drop-shadow-lg"
            />
          </g>
          
          {/* XAVORO text integrated into the design */}
          <text
            x="100"
            y="90"
            textAnchor="middle"
            className="fill-current text-white font-bold tracking-wider"
            style={{ fontSize: '16px', fontFamily: 'Inter, sans-serif' }}
          >
            XAVORO
          </text>
        </svg>
      </div>
      
      {variant === 'light' && (
        <span className={`font-bold ${textSizeClasses[size]} text-white tracking-wide`}>
          XAVORO
          <span className="block text-xs font-medium opacity-80 -mt-1">
            DIGITAL
          </span>
        </span>
      )}
      
      {variant === 'dark' && (
        <span className={`font-bold ${textSizeClasses[size]} text-gray-900 tracking-wide`}>
          XAVORO
          <span className="block text-xs font-medium opacity-80 -mt-1">
            DIGITAL
          </span>
        </span>
      )}
    </div>
  );
};

export default Logo;