import React from 'react';
import { ArrowRight, TrendingUp, Users, Target } from 'lucide-react';

const Hero = () => {
  return (
    <section id="home" className="gradient-bg min-h-screen flex items-center relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-black/10"></div>
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 to-transparent"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-white">
            <div className="inline-flex items-center bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 mb-6">
              <TrendingUp className="h-4 w-4 mr-2 text-orange-400" />
              <span className="text-sm font-medium">Growing businesses since 2025</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold leading-tight mb-6">
              Transform Your
              <span className="block text-orange-400">Digital Presence</span>
            </h1>
            
            <p className="text-xl mb-8 text-blue-100 leading-relaxed">
              We help ambitious businesses grow their online presence through strategic digital marketing, 
              compelling content, and data-driven campaigns that deliver measurable results.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <a
                href="#contact"
                className="orange-gradient text-white px-8 py-4 rounded-full font-semibold inline-flex items-center justify-center hover:shadow-xl transition-all duration-300 hover:scale-105"
              >
                Start Your Growth Journey
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
              <a
                href="#services"
                className="border-2 border-white/30 text-white px-8 py-4 rounded-full font-semibold hover:bg-white/10 transition-all duration-300 text-center"
              >
                Explore Services
              </a>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-400">200+</div>
                <div className="text-blue-200 text-sm">Happy Clients</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-400">500%</div>
                <div className="text-blue-200 text-sm">Avg ROI Increase</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-400">50+</div>
                <div className="text-blue-200 text-sm">Team Experts</div>
              </div>
            </div>
          </div>
          
          <div className="hidden lg:block">
            <div className="relative">
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <div className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <div className="bg-orange-500 p-3 rounded-lg">
                      <Target className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold">Strategic Planning</h3>
                      <p className="text-blue-200 text-sm">Data-driven marketing strategies</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="bg-blue-500 p-3 rounded-lg">
                      <Users className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold">Expert Team</h3>
                      <p className="text-blue-200 text-sm">Certified digital marketing professionals</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="bg-green-500 p-3 rounded-lg">
                      <TrendingUp className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold">Proven Results</h3>
                      <p className="text-blue-200 text-sm">Measurable growth and ROI</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;