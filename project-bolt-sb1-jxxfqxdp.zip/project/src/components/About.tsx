import React from 'react';
import { Award, Users, Clock, TrendingUp } from 'lucide-react';

const About = () => {
  const stats = [
    { icon: Users, number: '200+', label: 'Satisfied Clients' },
    { icon: Award, number: '15+', label: 'Industry Awards' },
    { icon: Clock, number: '1+', label: 'Years Experience' },
    { icon: TrendingUp, number: '500%', label: 'Average ROI Growth' }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl font-bold hero-text mb-6">
              We're Digital Marketing Experts Who Deliver Results
            </h2>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              At Xavoro Digital, we're passionate about helping businesses thrive in the digital landscape. 
              Our team of certified professionals combines creativity with data-driven strategies to deliver 
              marketing solutions that not only look great but perform exceptionally.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Founded in 2025, we've quickly established ourselves as a trusted partner for businesses 
              ranging from ambitious startups to established enterprises. Our commitment to innovation, 
              transparency, and results has earned us recognition as one of the most promising 
              digital marketing agencies in the industry.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                <span className="text-gray-700">Google Certified Partner Agency</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                <span className="text-gray-700">Facebook Marketing Partner</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                <span className="text-gray-700">HubSpot Solutions Partner</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                <span className="text-gray-700">Certified B Corporation</span>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-6">
            {stats.map((stat, index) => (
              <div key={index} className="bg-gradient-to-br from-blue-50 to-orange-50 p-6 rounded-2xl card-hover text-center">
                <div className="orange-gradient p-3 rounded-lg w-fit mx-auto mb-4">
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
                <div className="stat-number text-3xl font-bold mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-600 font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="mt-20">
          <h3 className="text-3xl font-bold text-center hero-text mb-12">
            Our Core Values
          </h3>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="gradient-bg p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <TrendingUp className="h-8 w-8 text-white" />
              </div>
              <h4 className="text-xl font-semibold mb-3 text-gray-900">Results-Driven</h4>
              <p className="text-gray-600 leading-relaxed">
                Every strategy we implement is designed to deliver measurable results 
                and contribute to your bottom line growth.
              </p>
            </div>
            
            <div className="text-center">
              <div className="gradient-bg p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Users className="h-8 w-8 text-white" />
              </div>
              <h4 className="text-xl font-semibold mb-3 text-gray-900">Client-Centric</h4>
              <p className="text-gray-600 leading-relaxed">
                Your success is our success. We work as an extension of your team, 
                understanding your goals and challenges deeply.
              </p>
            </div>
            
            <div className="text-center">
              <div className="gradient-bg p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Award className="h-8 w-8 text-white" />
              </div>
              <h4 className="text-xl font-semibold mb-3 text-gray-900">Innovation First</h4>
              <p className="text-gray-600 leading-relaxed">
                We stay ahead of digital trends and technologies to ensure 
                your brand remains competitive in the evolving landscape.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;