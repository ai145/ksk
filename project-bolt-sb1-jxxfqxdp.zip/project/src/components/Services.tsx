import React from 'react';
import { 
  Search, 
  Share2, 
  PenTool, 
  BarChart3, 
  Mail, 
  Smartphone,
  Globe,
  Target
} from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Search,
      title: 'Search Engine Optimization',
      description: 'Boost your organic visibility and drive qualified traffic with our comprehensive SEO strategies.',
      features: ['Keyword Research', 'On-Page Optimization', 'Technical SEO', 'Link Building']
    },
    {
      icon: Share2,
      title: 'Social Media Marketing',
      description: 'Build your brand presence across all major social platforms with engaging content and targeted campaigns.',
      features: ['Content Creation', 'Community Management', 'Paid Advertising', 'Analytics & Reporting']
    },
    {
      icon: PenTool,
      title: 'Content Marketing',
      description: 'Create compelling content that resonates with your audience and drives meaningful engagement.',
      features: ['Blog Writing', 'Video Production', 'Infographics', 'Content Strategy']
    },
    {
      icon: Target,
      title: 'Pay-Per-Click Advertising',
      description: 'Maximize your ROI with expertly managed PPC campaigns across Google, Facebook, and LinkedIn.',
      features: ['Campaign Setup', 'Bid Management', 'A/B Testing', 'Conversion Tracking']
    },
    {
      icon: Mail,
      title: 'Email Marketing',
      description: 'Nurture leads and retain customers with personalized email campaigns that convert.',
      features: ['List Building', 'Automation', 'Design Templates', 'Performance Analysis']
    },
    {
      icon: Globe,
      title: 'Web Development',
      description: 'Create stunning, responsive websites that provide exceptional user experiences and drive conversions.',
      features: ['Responsive Design', 'E-commerce', 'CMS Integration', 'Performance Optimization']
    },
    {
      icon: BarChart3,
      title: 'Analytics & Reporting',
      description: 'Make data-driven decisions with comprehensive tracking, analysis, and actionable insights.',
      features: ['Custom Dashboards', 'Performance Metrics', 'ROI Analysis', 'Monthly Reports']
    },
    {
      icon: Smartphone,
      title: 'Mobile Marketing',
      description: 'Reach your audience where they are with mobile-first marketing strategies and app promotion.',
      features: ['App Store Optimization', 'Mobile Ads', 'SMS Marketing', 'Mobile UX']
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold hero-text mb-4">
            Comprehensive Digital Marketing Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From strategy to execution, we provide end-to-end digital marketing solutions 
            that drive growth and deliver measurable results for your business.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div key={index} className="service-card rounded-2xl p-6 card-hover">
              <div className="orange-gradient p-3 rounded-lg w-fit mb-4">
                <service.icon className="h-6 w-6 text-white" />
              </div>
              
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                {service.title}
              </h3>
              
              <p className="text-gray-600 mb-4 leading-relaxed">
                {service.description}
              </p>
              
              <ul className="space-y-2">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="text-sm text-gray-500 flex items-center">
                    <div className="w-1.5 h-1.5 bg-orange-500 rounded-full mr-2"></div>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <a
            href="#contact"
            className="orange-gradient text-white px-8 py-3 rounded-full font-semibold hover:shadow-lg transition-all duration-300 hover:scale-105 inline-block"
          >
            Discuss Your Project
          </a>
        </div>
      </div>
    </section>
  );
};

export default Services;